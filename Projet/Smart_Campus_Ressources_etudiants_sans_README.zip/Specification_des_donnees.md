# Projet Smart Campus — Spécification des données

Ce document décrit les données qui alimentent votre plateforme. Il ne décrit **pas** la plateforme : concevoir l'architecture, choisir les outils et configurer les traitements fait partie du travail demandé.

## 1. Principe

Les capteurs et les équipements sont **simulés** : un script de rejeu lit un fichier de mesures et publie chaque ligne sur un broker MQTT, comme le feraient des objets connectés. Ce rejeu **ne constitue pas** une transmission radio LoRaWAN réelle : il alimente votre plateforme de la même façon, sans matériel.

```text
generer_donnees.py → donnees.csv → rejeu.py → broker MQTT → (votre plateforme)
```

## 2. Obtenir votre jeu de données

Chaque équipe utilise une **graine** personnelle, communiquée par l'enseignant. Le jeu de données couvre les **24 dernières heures** au moment de la génération, avec une mesure toutes les 5 minutes. Les valeurs et les anomalies diffèrent d'une équipe à l'autre.

```bash
pip install paho-mqtt
python generer_donnees.py --cas energie   --graine VOTRE_GRAINE --sortie donnees.csv
python generer_donnees.py --cas eclairage --graine VOTRE_GRAINE --sortie donnees.csv
```

Générez votre fichier **le jour où vous testez** : les horodatages sont relatifs à l'instant de génération. Si vous le regénérez, les anomalies changent de date mais pas de nature.

## 3. Cas A — Énergie d'un bâtiment

### Fichier `donnees.csv`

| Champ | Type | Description |
|---|---|---|
| `horodatage` | texte ISO 8601, UTC | Instant de la mesure (`2026-11-05T08:05:00Z`) |
| `capteur` | texte | Identifiant du compteur (`cpt-b1-01`) |
| `batiment` | texte | Bâtiment (`B1`, `B2`) |
| `puissance_w` | nombre | Puissance électrique instantanée, en watts |

Trois compteurs répartis dans deux bâtiments.

### Messages MQTT

- **Sujet** : `campus/<batiment>/energie/<capteur>`, bâtiment en minuscules (`campus/b1/energie/cpt-b1-01`).
- **Contenu** (JSON) :

  ```json
  {"horodatage": "2026-11-05T08:05:00Z", "capteur": "cpt-b1-01", "batiment": "B1", "puissance_w": 4200.5}
  ```

### Indicateurs attendus (exemples)

Puissance par capteur dans le temps, puissance moyenne par bâtiment, dernière valeur par capteur, nombre d'alertes.

## 4. Cas B — Éclairage extérieur intelligent

### Fichier `donnees.csv`

| Champ | Type | Description |
|---|---|---|
| `horodatage` | texte ISO 8601, UTC | Instant de la mesure |
| `luminaire` | texte | Identifiant du luminaire (`lum-z1-01`) |
| `zone` | texte | Zone du campus (`Z1`, `Z2`) |
| `etat` | entier 0 ou 1 | 1 si le luminaire est allumé |
| `puissance_w` | nombre | Puissance consommée, en watts |
| `luminosite_lux` | nombre | Luminosité mesurée au niveau du luminaire, en lux |

Quatre luminaires répartis dans deux zones.

### Plage de fonctionnement prévue

Les luminaires doivent être **allumés de 18 h à 6 h (heure UTC)** et **éteints le reste du temps**.

### Messages MQTT

- **Sujet** : `campus/<zone>/eclairage/<luminaire>`, zone en minuscules (`campus/z1/eclairage/lum-z1-01`).
- **Contenu** (JSON) :

  ```json
  {"horodatage": "2026-11-05T22:05:00Z", "luminaire": "lum-z1-01", "zone": "Z1", "etat": 1, "puissance_w": 56.8, "luminosite_lux": 150.0}
  ```

### Indicateurs attendus (exemples)

État des luminaires, consommation par zone, luminosité mesurée, nombre d'alertes.

## 5. Situations anormales

Votre jeu de données contient des situations anormales que votre plateforme doit **repérer** et **signaler**. Leur nature est décrite ci-dessous ; leur nombre, leur date et le capteur concerné vous sont inconnus et diffèrent selon la graine.

| Cas | Situations à prévoir |
|---|---|
| A — Énergie | un **dépassement** de consommation, un **capteur qui ne répond plus** pendant une période prolongée, une **valeur impossible** |
| B — Éclairage | un luminaire **allumé en dehors de la plage prévue**, une **panne présumée** (état allumé mais consommation quasi nulle), un luminaire qui **ne répond plus**, une **valeur impossible** |

Pour être validé, le projet doit détecter **au moins deux** situations, dont **l'absence prolongée de données**. Votre rapport expliquera comment vous avez choisi vos seuils (à partir de l'observation de vos données, pas de valeurs recopiées).

## 6. Le rejeu

```bash
python rejeu.py --fichier donnees.csv --hote localhost --vitesse 600
```

| Option | Rôle |
|---|---|
| `--fichier` | fichier de mesures à rejouer |
| `--hote`, `--port` | adresse du broker MQTT |
| `--vitesse` | facteur d'accélération (600 : 10 minutes de données par seconde, 1 : temps réel, 0 : sans attente) |
| `--utilisateur`, `--mot-de-passe` | identifiants MQTT (à partir du jalon J5) |
| `--cafile` | certificat de l'autorité : active TLS (approfondissement D) |

Le script est fourni **à titre d'exemple** : vous pouvez l'adapter, le conteneuriser ou le réécrire.

## 7. À savoir

- Les horodatages sont en **UTC**. Un message porte l'instant de la **mesure**, pas celui de sa réception.
- Le rejeu accélère le temps : une alerte fondée sur l'horloge de votre machine ne se comporte pas comme sur des mesures en temps réel. Réfléchissez à l'horloge de référence à utiliser pour détecter une absence de données.
- Les données sont synthétiques ; aucune donnée personnelle n'est concernée.
