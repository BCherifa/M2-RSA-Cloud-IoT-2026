#!/usr/bin/env python3
"""Générateur de jeux de données du projet Smart Campus.

Deux cas d'usage :
  - energie    : consommation électrique de capteurs répartis dans des bâtiments ;
  - eclairage  : état et consommation de luminaires extérieurs.

Chaque équipe utilise une graine différente : les données (valeurs, anomalies, dates)
diffèrent d'une équipe à l'autre. Les données couvrent les dernières 24 heures au moment
de la génération, en heure UTC.

Exemples :
  python generer_donnees.py --cas energie   --graine 123 --sortie donnees.csv
  python generer_donnees.py --cas eclairage --graine 123 --sortie donnees.csv
"""
import argparse
import csv
import math
import random
from datetime import datetime, timedelta, timezone

PLAGE_ALLUME = (18, 6)  # éclairage prévu de 18 h à 6 h (UTC)


def fenetre_libre(rnd, candidats, longueur):
    """Choisit le début d'une plage de `longueur` mesures entièrement contenue dans `candidats`."""
    ensemble = set(candidats)
    debuts = [i for i in candidats if all((i + k) in ensemble for k in range(longueur))]
    return rnd.choice(debuts) if debuts else rnd.choice(candidats)


def generer_energie(rnd, debut, n, pas):
    capteurs = [("cpt-b1-01", "B1", 1.0), ("cpt-b1-02", "B1", 0.7), ("cpt-b2-01", "B2", 1.3)]
    capteurs = [(nom, bat, coef * rnd.uniform(0.85, 1.15)) for nom, bat, coef in capteurs]
    noms = [c[0] for c in capteurs]
    rnd.shuffle(noms)
    s_pic, s_muet, s_aberrant = noms
    i_pic = rnd.randint(n // 4, n // 2)
    n_pic = 3
    n_muet = rnd.randint(90, 150) // pas
    i_muet = rnd.randint(n // 2, 3 * n // 4 - n_muet)
    i_aberrant = rnd.randint(n // 4, 3 * n // 4)
    amplitude = rnd.randint(6000, 9000)
    valeur_aberrante = rnd.choice([99999.0, -500.0])

    lignes = []
    for i in range(n):
        t = debut + timedelta(minutes=i * pas)
        heure = t.hour + t.minute / 60
        activite = max(0.0, math.sin((heure - 6) / 12 * math.pi))
        for nom, batiment, coef in capteurs:
            valeur = coef * (800 + 3200 * activite) + rnd.gauss(0, 60)
            if nom == s_pic and i_pic <= i < i_pic + n_pic:
                valeur += amplitude
            if nom == s_muet and i_muet <= i < i_muet + n_muet:
                continue
            aberrant = nom == s_aberrant and i == i_aberrant
            if aberrant:
                valeur = valeur_aberrante
            lignes.append((t.strftime("%Y-%m-%dT%H:%M:%SZ"), nom, batiment, round(valeur if aberrant else max(valeur, 0.0), 1)))
    en_tete = ["horodatage", "capteur", "batiment", "puissance_w"]

    def date(i):
        return (debut + timedelta(minutes=i * pas)).strftime("%Y-%m-%d %H:%M UTC")
    solution = [
        f"Pic de consommation ({s_pic}) : {n_pic} mesures à partir de {date(i_pic)} (+{amplitude} W)",
        f"Capteur muet ({s_muet}) : de {date(i_muet)} à {date(i_muet + n_muet)}",
        f"Valeur aberrante ({s_aberrant}) : {valeur_aberrante} W à {date(i_aberrant)}",
    ]
    return en_tete, lignes, solution


def generer_eclairage(rnd, debut, n, pas):
    luminaires = [("lum-z1-01", "Z1"), ("lum-z1-02", "Z1"), ("lum-z2-01", "Z2"), ("lum-z2-02", "Z2")]
    noms = [l[0] for l in luminaires]
    rnd.shuffle(noms)
    s_hors_plage, s_panne, s_muet, s_aberrant = noms

    def prevu_allume(i):
        h = (debut + timedelta(minutes=i * pas)).hour
        return h >= PLAGE_ALLUME[0] or h < PLAGE_ALLUME[1]

    nuit = [i for i in range(n) if prevu_allume(i)]
    jour = [i for i in range(n) if 9 <= (debut + timedelta(minutes=i * pas)).hour < 15]
    n_hors = max(2, 90 // pas)
    n_panne = max(2, rnd.randint(60, 120) // pas)
    n_muet = max(2, rnd.randint(90, 150) // pas)
    i_hors = fenetre_libre(rnd, jour, n_hors)
    i_panne = fenetre_libre(rnd, nuit, n_panne)
    i_muet = rnd.randint(n // 4, 3 * n // 4 - n_muet)
    i_aberrant = rnd.randint(n // 4, 3 * n // 4)

    lignes = []
    for i in range(n):
        t = debut + timedelta(minutes=i * pas)
        heure = t.hour + t.minute / 60
        lux_ambiant = max(0.0, math.sin((heure - 6) / 12 * math.pi)) * 18000
        for nom, zone in luminaires:
            etat = 1 if prevu_allume(i) else 0
            if nom == s_hors_plage and i_hors <= i < i_hors + n_hors:
                etat = 1
            puissance = 55 + rnd.gauss(0, 2) if etat else abs(rnd.gauss(0, 0.3))
            if nom == s_panne and i_panne <= i < i_panne + n_panne:
                puissance = abs(rnd.gauss(0, 0.3))      # état « allumé » mais aucune consommation
            if nom == s_muet and i_muet <= i < i_muet + n_muet:
                continue
            if nom == s_aberrant and i == i_aberrant:
                puissance = 9999.0
            lux = max(0.0, lux_ambiant * rnd.uniform(0.9, 1.1)) + (150 if etat else 0)
            lignes.append((t.strftime("%Y-%m-%dT%H:%M:%SZ"), nom, zone, etat, round(puissance, 1), round(lux, 1)))
    en_tete = ["horodatage", "luminaire", "zone", "etat", "puissance_w", "luminosite_lux"]

    def date(i):
        return (debut + timedelta(minutes=i * pas)).strftime("%Y-%m-%d %H:%M UTC")
    solution = [
        f"Allumé hors plage ({s_hors_plage}) : de {date(i_hors)} à {date(i_hors + n_hors)}",
        f"Panne présumée ({s_panne}) : état allumé sans consommation, de {date(i_panne)} à {date(i_panne + n_panne)}",
        f"Luminaire muet ({s_muet}) : de {date(i_muet)} à {date(i_muet + n_muet)}",
        f"Valeur aberrante ({s_aberrant}) : 9999 W à {date(i_aberrant)}",
    ]
    return en_tete, lignes, solution


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--cas", choices=["energie", "eclairage"], required=True)
    parser.add_argument("--graine", type=int, required=True, help="graine aléatoire propre à l'équipe")
    parser.add_argument("--heures", type=int, default=24)
    parser.add_argument("--pas", type=int, default=5, help="minutes entre deux mesures")
    parser.add_argument("--sortie", default="donnees.csv")
    parser.add_argument("--solution", action="store_true", help="affiche les anomalies insérées (enseignant)")
    args = parser.parse_args()

    rnd = random.Random(args.graine)
    fin = datetime.now(timezone.utc).replace(second=0, microsecond=0)
    debut = fin - timedelta(hours=args.heures)
    n = args.heures * 60 // args.pas
    generer = generer_energie if args.cas == "energie" else generer_eclairage
    en_tete, lignes, solution = generer(rnd, debut, n, args.pas)

    with open(args.sortie, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(en_tete)
        w.writerows(lignes)
    print(f"{len(lignes)} mesures écrites dans {args.sortie} (cas {args.cas}, graine {args.graine})")
    if args.solution:
        print("Anomalies insérées :")
        for ligne in solution:
            print("  -", ligne)


if __name__ == "__main__":
    main()
