#!/usr/bin/env python3
"""Rejoue un fichier de mesures sur un broker MQTT, comme le feraient des capteurs.

Chaque ligne du fichier devient un message JSON publié sur un sujet :
  campus/<batiment>/energie/<capteur>        (cas énergie)
  campus/<zone>/eclairage/<luminaire>        (cas éclairage)

Exemples :
  python rejeu.py --fichier donnees.csv --hote localhost --vitesse 600
  python rejeu.py --fichier donnees.csv --hote localhost --port 8883 --cafile certs/ca.crt \\
                  --utilisateur capteur --mot-de-passe ...

La vitesse est un facteur d'accélération : 600 rejoue 10 minutes de données par seconde,
1 rejoue en temps réel, 0 publie tout sans attendre.
Dépendance : pip install paho-mqtt
"""
import argparse
import csv
import json
import time
from datetime import datetime

import paho.mqtt.client as mqtt

ENTIERS = {"etat"}


def sujet(ligne):
    if "capteur" in ligne:
        return f"campus/{ligne['batiment'].lower()}/energie/{ligne['capteur']}"
    return f"campus/{ligne['zone'].lower()}/eclairage/{ligne['luminaire']}"


def charge(ligne):
    resultat = {}
    for cle, valeur in ligne.items():
        if cle in ENTIERS:
            resultat[cle] = int(valeur)
        elif cle in ("horodatage", "capteur", "batiment", "luminaire", "zone"):
            resultat[cle] = valeur
        else:
            resultat[cle] = float(valeur)
    return resultat


def creer_client(utilisateur, mot_de_passe, cafile):
    try:
        client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id="rejeu")
    except AttributeError:  # paho-mqtt 1.x
        client = mqtt.Client(client_id="rejeu")
    if utilisateur:
        client.username_pw_set(utilisateur, mot_de_passe)
    if cafile:
        client.tls_set(ca_certs=cafile)
    return client


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--fichier", default="donnees.csv")
    parser.add_argument("--hote", default="localhost")
    parser.add_argument("--port", type=int, default=1883)
    parser.add_argument("--vitesse", type=float, default=600.0)
    parser.add_argument("--utilisateur")
    parser.add_argument("--mot-de-passe")
    parser.add_argument("--cafile", help="certificat de l'autorité (active TLS)")
    args = parser.parse_args()

    with open(args.fichier, newline="", encoding="utf-8") as f:
        lignes = list(csv.DictReader(f))

    client = creer_client(args.utilisateur, args.mot_de_passe, args.cafile)
    client.connect(args.hote, args.port)
    client.loop_start()

    precedent = None
    dernier = None
    for ligne in lignes:
        instant = datetime.strptime(ligne["horodatage"], "%Y-%m-%dT%H:%M:%SZ")
        if precedent is not None and args.vitesse > 0:
            attente = (instant - precedent).total_seconds() / args.vitesse
            if attente > 0:
                time.sleep(attente)
        precedent = instant
        dernier = client.publish(sujet(ligne), json.dumps(charge(ligne)), qos=1)

    if dernier is not None:
        dernier.wait_for_publish()
    client.loop_stop()
    client.disconnect()
    print(f"{len(lignes)} messages publiés")


if __name__ == "__main__":
    main()
